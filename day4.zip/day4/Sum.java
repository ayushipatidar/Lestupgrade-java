import java.util.Scanner
class Sum{

int sum=0;
public static void main(String arr[]){
Scanner sc=new Scanner(System.in);
int[] number=new int[5];

           for(int i=0;i<5;i++){

                  number[i]=sc.nextInt();
                  }

           for(int i=0;i<5;i++){
                  sum=number[i]+sum;

                  }
           System.out.println("Sum = "+sum) ;

    } 
  }