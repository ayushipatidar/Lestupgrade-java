import java.util.Scanner

class Avenger{

 
 Scanner sc=new Scanner(System.in)
 
 void getDetails(){

 System.out.println("enter a name");
 String name=sc.next();
 
 System.out.println("enter a power");
 String power=sc.next(); 

 System.out.println("enter a age");
 int age=sc.nextInt();

 system.out.println("enter a planet");
 String planet=sc.next();
 
 System.out.println("enter a weapon");
 String weapon=sc.next();
            }
 void displayDetails(){
 
 System.out.println("the name is "+name);
 System.out.println("the age is "+age); 
 System.out.println("the power is "+power);
 System.out.println("the planet is"+planet);         
 System.out.println("the weapon is "+weapon);     

            }
  
public static void main(String arr[]){

Avenger[] avenger=new Avenger[5];

for(int i=0;i<5;i++)
             {
                avenger[i]=new Avenger();
                avenger[i].getdetails();
             }

 for(int i=0;i<5;i++)
             {
                 avenger[i].displayDetails();
             }


      }
}