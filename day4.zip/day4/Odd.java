import java.util.Scanner
class Odd{

public static void main(String arr[]){

  Scanner sc = new Scanner(System.in);
  int[] number=new int[5];

  for(int i=0;i<5;i++)
     {
       number[i]=sc.nextInt();
     }

  for(int i=0;i<5;i++)
     {
          if((number[i]/2)==0)
                       {
                        System.out.println(number[i]);
   
                       }     


     }

    
   }

}